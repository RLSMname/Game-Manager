import useSignIn from 'react-auth-kit/hooks/useSignIn';
import { zodResolver } from "@hookform/resolvers/zod";
import {useForm} from 'react-hook-form'
import {z} from 'zod'
import { useNavigate } from "react-router-dom";
const schema = z.object({
    email: z.string().email(),
    password: z.string()
});

export const LogIn = () => {
    const signIn = useSignIn();
    const navigate = useNavigate();

    const {
        register,
        handleSubmit,
        setError,
        formState: { errors, isSubmitting },
      } = useForm({
        resolver: zodResolver(schema),
      });


    const onSubmit = async (data) => {
        try {
            const response = await fetch("http://localhost:5000/api/misc/login",
            {
                method: "POST",
                body: JSON.stringify({
                email:data.email,
                password:data.password
                }),
                headers: {"Content-type": "application/json; charset=UTF-8"}
              });
            const respData = await response.json();
            signIn({
                auth: {
                    token: respData.token,
                    type: 'Bearer'
                },
                expiresIn: 3600,
                authState: {email: data.email}
            });
            navigate("/games");
        } catch (error) {
            setError("root", {
                message: error.message,
                });
        }
    }
  return (
    <>
    <h1>LogIn</h1>
    <form onSubmit={handleSubmit(onSubmit)}>
        <input {...register("email")} type="email" placeholder="Email" />
        
        {errors.email && (<div>{errors.email.message}</div>)} 

        <input {...register("password")} type="password" placeholder="Password" />
        
        {errors.password && (<div>{errors.password.message}</div>)} 

        <button disabled={isSubmitting} type="submit">
        {isSubmitting ? "Loading..." : "Submit"}
        </button>

        {errors.root && <div>{errors.root.message}</div>}    
    </form>
    </>
  )
}

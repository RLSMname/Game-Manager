import { useState } from "react";
import { useDevsContext } from "../state/context";
import { DevTile } from "./DevTile";
import { DevEditForm } from "./ui/DevEditForm";
import Popup from 'reactjs-popup';
import { DevAddForm } from "./ui/DevAddForm";

export const DevsListRenderer = () => {
    const {devs, handleDelete} = useDevsContext();

    const handleDeleteClick = (id) => {
        console.log("delete button clicked");
        handleDelete(id);
    };


    const [editDeveloperId, setEditDeveloperId] = useState(null);

    const handleEditClick = (id) => {
        console.log("edit button clicked");
        setEditDeveloperId(id); 
    };

    const handleCloseEdit = () => {
        console.log("close edit modal");
        setEditDeveloperId(null); 
    };


    const [isAddModalOpen, setIsAddModalOpen] = useState(false); 

    const handleAddClick = () => {
        console.log("add button clicked");
        setIsAddModalOpen(true); 
    };

    const handleCloseAdd = () => {
        console.log("close add modal");
        setIsAddModalOpen(false);
    };

  return (
    <div>
        <h2>Developers</h2>
        <button onClick={handleAddClick}>Add Developer</button> 
        <ul>
            {devs.map(
                developer => 
                <li key={developer.id}>
                    <DevTile id={developer.id} name={developer.name} />
                    <button onClick={() => handleEditClick(developer.id)}>Edit</button>
                    <button onClick={() => handleDeleteClick(developer.id)}>Delete</button>
                </li>
            )}
        </ul>


            <Popup open={editDeveloperId !== null} onClose={handleCloseEdit}>
                <div>
                    <h2>Edit Developer</h2>
                    <DevEditForm
                        developerId={editDeveloperId}
                        initialData={devs.find(dev => dev.id === editDeveloperId)}
                        onClose={handleCloseEdit}
                    />
                </div>
            </Popup>

        <Popup open={isAddModalOpen} onClose={handleCloseAdd}>
            <div>
                <h2>Add Developer</h2>
                <DevAddForm onClose={handleCloseAdd} />
            </div>
        </Popup>
    </div>
  )
}

import PropTypes from 'prop-types';
export const DevTile = ({id, name}) => {
  return (
        <h3>{id} - {name}</h3>
  )
}

DevTile.propTypes = {
    id: PropTypes.number.isRequired,
    name: PropTypes.string.isRequired
  };
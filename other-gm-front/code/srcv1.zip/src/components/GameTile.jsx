import PropTypes from 'prop-types';
export const GameTile = ({id, name}) => {
  return (
        <h3>{id} - {name}</h3>
  )
}

GameTile.propTypes = {
    id: PropTypes.number.isRequired,
    name: PropTypes.string.isRequired
  };
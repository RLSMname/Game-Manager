import { useState } from 'react';
import { useGamesContext } from '../state/contextGame'
import { GameTile } from './GameTile';
import Popup from 'reactjs-popup';
import { Link } from "react-router-dom";
import { GameAddForm } from './ui/GameAddForm';
import { GameEditForm } from './ui/GameEditForm';
import InfiniteScroll from 'react-infinite-scroll-component'
export const GameListRenderer = () => {
    const {games, nextPage, prevPage, currentPage, totalPages, handleDelete} = useGamesContext();
    

    const handleDeleteClick = (id) => {
        console.log("delete button clicked");
        handleDelete(id);
    };


    const [editGameId, setEditGameId] = useState(null);

    const handleEditClick = (id) => {
        console.log("edit button clicked");
        setEditGameId(id); 
    };

    const handleCloseEdit = () => {
        console.log("close edit modal");
        setEditGameId(null); 
    };


    const [isAddModalOpen, setIsAddModalOpen] = useState(false); 

    const handleAddClick = () => {
        console.log("add button clicked");
        setIsAddModalOpen(true); 
    };

    const handleCloseAdd = () => {
        console.log("close add modal");
        setIsAddModalOpen(false);
    };
    



  return (
    <div>
        <h2>Games</h2>
        <h3>Page: {currentPage}/{totalPages}</h3>
        <button onClick={handleAddClick}>Add Game</button> 
        <ul>
            {games.map(
                game => 
                <li key={game.id}>
                    <GameTile id={game.id} name={game.name} />
                    <button onClick={() => handleEditClick(game.id)}>Edit</button>
                    <button onClick={() => handleDeleteClick(game.id)}>Delete</button>
                    <Link target="_blank" to={{pathname: `/${game.id}`}} state={{ id: game.id  }}><button >View</button></Link>
                </li>
            )}

        </ul>


            <Popup open={editGameId !== null} onClose={handleCloseEdit}>
                <div>
                    <h2>Edit Developer</h2>
                    <GameEditForm
                        gameId={editGameId}
                        initialData={games.find(game => game.id === editGameId)}
                        onClose={handleCloseEdit}
                    />
                </div>
            </Popup>

        <Popup open={isAddModalOpen} onClose={handleCloseAdd}>
            <div>
                <h2>Add Developer</h2>
                <GameAddForm onClose={handleCloseAdd} />
            </div>
        </Popup>
        {currentPage > 1 && <button onClick={prevPage}>Prev</button> }
        {currentPage < totalPages && <button onClick={nextPage}>Next</button>}
        
    </div>
  )
}

import PropTypes from 'prop-types';
export const GameCard = ({name, description, developer, price}) => {
  return (
    <div>
        <h3>{name}</h3>
        <h4><em>Developer:</em>{developer}</h4>
        <h4><em>Price:</em>{price}</h4>
        <h5>{description}</h5>
    </div>
  )
}

GameCard.propTypes = {
    name: PropTypes.string.isRequired,
    developer: PropTypes.string.isRequired,
    description: PropTypes.string.isRequired,
    price: PropTypes.number.isRequired,
  };
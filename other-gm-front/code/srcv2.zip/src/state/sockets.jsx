import { createContext, useContext, useEffect, useState } from "react";
import { io } from "socket.io-client";

export const SocketContext = createContext(undefined);
export const useSocketContext = () => useContext(SocketContext);
export const SocketProvider = ({ children }) => {
    const [socket, setSocket] = useState(null);
    const [isServerOnline, setIsServerOnline] = useState(false);

    useEffect(() => {
        const socketIo = io("http://localhost:3000");
        socketIo.connect();
        socketIo.on("connect", () => {
          console.log("Socket connected");
          setSocket(socketIo);
        });
    
        return () => {
          socketIo.disconnect();
        };
      }, []);


      useEffect(() => {
            const checkServerStatus = () => {
            fetch('http://localhost:5000/api/misc/health-check', {
                method: "GET",
                headers: {"Content-type": "application/json; charset=UTF-8",},
            })
            .then((response) => {
                console.log("Health Check Response Status:", response.status);
                console.log(
                    "Health Check Response Status Text:",
                    response.statusText
                );
                if (!response.ok) {
                    console.log("Server is offline or returned an error");
                    setIsServerOnline(false);
                } else {
                    console.log("Server is online");
                    setIsServerOnline(true);
                }
                })
                .catch((error) => {
                
                setIsServerOnline(false);
                });
            };
            checkServerStatus();

            const interval = 20000; 
            const intervalId = setInterval(checkServerStatus, interval);

            return () => clearInterval(intervalId);
        }, []);

    const contextValue = {
        socket,
        setSocket,
        isServerOnline,
        setIsServerOnline
    }

    return(
        <SocketContext.Provider value={contextValue}>
            {children}
        </SocketContext.Provider>
    );
}

import { GameListRenderer } from '../../components/GameListRenderer'
import InfiniteScroll from 'react-infinite-scroll-component';
import { useState } from 'react';
import { useDevsContext } from '../../state/context';
import { GameTile } from '../../components/GameTile';



export const InfiniteScrollMechanism = () => {
    //idea for later
    // if you still want to have add and delete, using useState, create a variable for offset and limit
    

    const {devs} = useDevsContext();
    const [list,setList]=useState([]);
    const [page,setPage]=useState(0);
    const [totalPages,setTotalPages]=useState(1);

    const canLoadMore = () => {
        return page < totalPages; 
    }
  

  const activateInfiniteScroll=()=>{
    const select = document.querySelector("#select-dev")
    const dev=select.value;
    console.log("DEV:",dev);

    const url="http://localhost:5000/api/games/countGamesByDev";
        fetch(url, {
          method: "PATCH", 
          headers: {
            "Content-Type": "application/json",
            // 'Content-Type': 'application/x-www-form-urlencoded',
          },
          body:JSON.stringify({dev:dev})
        }).then(
          (data)=> data.json()
        ).then( data =>{
            console.log("data count:",data.count);
            setTotalPages(Math.ceil(data.count / 5))
            console.log("total pages:",Math.ceil(data.count / 5));
            
          }
            
        ).catch(
          err => console.log("ERROR: ",err)
        );


        const url2="http://localhost:5000/api/games/scroll"
        console.log("DEV:",dev);
        fetch(url2, {
            method: "PATCH", 
            headers: {
              "Content-Type": "application/json",
              // 'Content-Type': 'application/x-www-form-urlencoded',
            },
            body:JSON.stringify({dev:dev, page:1})
          }).then(
            (data)=> data.json()
          ).then((data)=>{
            console.log("data:",data);
             setList(data);
             setPage(1);}
          ).catch((err)=>
            console.error("Somethin went wrong when loading more games:",err)
          );
  }
  const pageLoader=()=>{
    // fetch page
    const url="http://localhost:5000/api/games/scroll"
    const select = document.querySelector("#select-dev")
    const dev=select.value;
    console.log("DEV:",dev);
    setTimeout( ()=>{
    fetch(url, {
        method: "PATCH", 
        headers: {
          "Content-Type": "application/json",
          // 'Content-Type': 'application/x-www-form-urlencoded',
        },
        body:JSON.stringify({dev:dev, page:page + 1})
      }).then(
        (data)=> data.json()
      ).then((data)=>{
        console.log("data:",data);
       setList(list.concat(data));
       setPage(page+1);}
      ).catch((err)=>
        console.error("Somethin went wrong when loading more games:",err)
      )});
    
  }
  return (
    <>
    <button onClick={activateInfiniteScroll}>Start loading games</button>
    <select id='select-dev'>
        {
            devs.map((d,i) =>{return <option key={i}  value={d.name}>{d.name}</option>})
        }
    </select>
        <InfiniteScroll dataLength={list.length} next={pageLoader} hasMore={canLoadMore()} loader={<p>loading...</p>} endMessage={<p>All games have been loaded!</p>}>
            <ul>
              {list.map(
                game => 
                  <li key={game.id}>
                      <GameTile id={game.id} name={game.name} />
                  </li>
              ) }
            </ul>
        </InfiniteScroll>
    </>
  )
}

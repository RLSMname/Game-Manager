
import { DevsProvider,useDevsContext } from "../../state/context"
import { InfiniteScrollMechanism } from "./InfiniteScrollMechanism"
import { GamesProvider } from "../../state/contextGame"

export const GamesHomeInfiniteScroll = () => {
  return (
    <DevsProvider>
        <InfiniteScrollMechanism/>
    </DevsProvider>
    )
}

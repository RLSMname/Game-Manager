import { GamesProvider, useGamesContext } from '../../state/contextGame'
import { GameListRenderer } from '../../components/GameListRenderer'

export const GamesHome = () => {

  return (
    <GamesProvider>
        <GameListRenderer/>
    </GamesProvider>
  )
}

import { DevsListRenderer } from '../../components/DevsListRenderer';
import { DevsProvider } from '../../state/context';

export const DevsHome = () => {
  return (
    <DevsProvider>
        <DevsListRenderer/>
    </DevsProvider>
  )
}
